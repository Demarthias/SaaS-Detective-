# SaaS-Detective | Web Intelligence Engine
**Version:** 2.0.0 (Manifest V3)
**Core Logic:** TypeScript

SaaS-Detective is a high-performance browser extension designed to identify technology stacks via local signature matching.

## Technical Specifications
* Manifest V3 Native
* Zero-telemetry execution
* Modular configuration for affiliate links
