// SaaS-Detective Background Service Worker (Manifest V3)
// This service worker is reserved for future enhancements:
// - Caching detection results
// - Batch processing multiple tabs
// - Analytics and logging
// Currently, all detection is handled by the content script (src/content.ts)
// and the popup UI (popup.js)
